<?php

class CurlRequestHandler {
    private $commonOptions;

    public function __construct() {
        $cookies = tempnam(sys_get_temp_dir(), 'cookie');
        $this->commonOptions = [
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_TIMEOUT => 500, 
            CURLOPT_CONNECTTIMEOUT => 225,
            CURLOPT_COOKIEFILE => $cookies,
            CURLOPT_COOKIEJAR => $cookies,
        ];
    }

    public function performCurlRequest($url, $requestType, $headers = [], $postFields = null, $specificOptions = []) {
        $ch = curl_init();
        $options = $this->commonOptions + [
            CURLOPT_URL => $url,
            CURLOPT_HTTPHEADER => $headers,
        ];

        if ($requestType === 'POST') {
            $options[CURLOPT_POST] = true;
            $options[CURLOPT_POSTFIELDS] = $postFields;
        } else {
            $options[CURLOPT_CUSTOMREQUEST] = $requestType;
        }
        curl_setopt_array($ch, $specificOptions + $options);

        $curlResponse = curl_exec($ch);
        curl_close($ch);

        return $curlResponse;
    }

    public function addCurlOption($option, $value) {
        $this->commonOptions[$option] = $value;
    }

    public function capture($string, $start, $end) {
        $str = explode($start, $string);
        $str = explode($end, $str[1]);  
        return $str[0];
    }
}